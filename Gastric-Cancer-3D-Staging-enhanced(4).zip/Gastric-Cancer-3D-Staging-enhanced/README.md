# Gastric Cancer 3D Staging Enhanced

Interactive Streamlit app for TRG, ypN, and ypT based gastric cancer staging.

## What is included

- Sidebar controls for TRG, ypN, and ypT.
- A staging matrix under the controls with the selected cell highlighted.
- 3D staging visualization with selectable boundary shells, lattice points, and matching-stage highlighting.
- Stage-specific KM survival curves for Stage I, II, IIIA, and IIIB.
- One survival summary panel showing 1-year / 3-year OS and 95% CI for the selected stage.

## Data note

The survival curves are rendered from the four stage-specific PDF files supplied with the project request, with the number-at-risk panels omitted in the app view. Before public release or manuscript use, confirm the final source citation and data-use permission for the KM figures and aggregate survival values.

## Run locally

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install --upgrade pip
.\.venv\Scripts\python -m pip install -r requirements.txt
.\.venv\Scripts\streamlit run app.py
```
